import React from 'react'

export default function DOM() {
  return (
    <div className="app">
        <div className="circle">
        <button>Change Shape</button>
        </div>
    </div>
  )
}
